export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const { path } = req.query;
  if (!path) return res.status(400).json({ error: 'no path' });

  const target = 'https://am.dapjisync.my.id/' + path;
  const API_KEY = 'amk_61ac0adc106a15b1dd7feecbf7e7bd7d40db156d';

  try {
    const opts = {
      method: req.method,
      headers: {
        'Content-Type': 'application/json',
        'x-apikey': API_KEY,
      },
    };

    if (req.method === 'POST' && req.body) {
      opts.body = JSON.stringify(req.body);
    }

    const upstream = await fetch(target, opts);
    const data = await upstream.json();
    return res.status(upstream.status).json(data);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}
